/*
** EPITECH PROJECT, 2023
** flag n
** File description:
** flag of my_printf n
*/
#include "my.h"

int my_printf_n(int *ptr, int *count)
{
    *ptr = *count;
    return 0;
}
