/*
** EPITECH PROJECT, 2021
** minishell
** File description:
** first
*/

#include "../include/mysh.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>

static void display_signal(int status)
{
    int termsig = 0;

    if (WIFSIGNALED(status) != 0) {
        termsig = WTERMSIG(status);
        if (termsig != 0 && termsig != SIGFPE) {
            my_printf(strsignal(termsig));
        }
        if (termsig == SIGFPE) {
            my_printf("Floating exception");
        }
        if (WCOREDUMP(status) != 0)
            my_printf(" (core dumped)");
        my_printf("\n");
    }
}

int execute(char **env, char **divised_line, char *buffer)
{
    pid_t pid = fork();
    int status = 0;
    char *path = (char *)malloc(100 * sizeof(char));

    if (pid == 0) {
        my_strcpy(path, "/usr/bin/");
        my_strcat(path, divised_line[0]);
        execve(path, divised_line, env);
        error_execve(divised_line[0]);
        exit(1);
    }
    wait(&status);
    display_signal(status);
    return status;
}

void error_execve(char *opt)
{
    my_printf(opt);
    my_printf(": Command not found.\n");
}

int check_builtin(char ***env, char *buffer)
{
    char **divised_line = copy_all(buffer);

    if (my_strcmp(divised_line[0], "env") == 0 ||
    my_strcmp(divised_line[0], "env\n") == 0 ||
    my_strcmp(divised_line[0], "setenv") == 0 ||
    my_strcmp(divised_line[0], "setenv\n") == 0 ||
    my_strcmp(divised_line[0], "unsetenv") == 0 ||
    my_strcmp(divised_line[0], "unsetenv\n") == 0 ||
    my_strcmp(divised_line[0], "exit") == 0 ||
    my_strcmp(divised_line[0], "exit\n") == 0 ||
    my_strcmp(divised_line[0], "cd") == 0 ||
    my_strcmp(divised_line[0], "cd\n") == 0) {
        specifique_function(env, divised_line);
    } else {
        return execute(*env, divised_line, buffer);
    }
    return 0;
}
