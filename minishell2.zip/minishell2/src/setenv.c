/*
** EPITECH PROJECT, 2021
** minishell
** File description:
** first
*/

#include "../include/mysh.h"

int my_setenv_checks(char **env, char **arg, int arg_n)
{
    if (arg_n == 1) {
        print_env(env);
        return 1;
    }
    if (arg_n > 3) {
        my_printf("setenv: Too many arguments.\n");
        return 1;
    }
    if (my_str_isalpha(arg[1]) == 0) {
        my_printf("setenv: Variable name must contain ");
        my_printf("alphanumeric characters.\n");
        return 1;
    }
    return 0;
}

void my_setenv(char ***env, char **arg)
{
    int arg_n = my_tablen(arg);

    if (my_setenv_checks(*env, arg, arg_n) == 1)
        return;
    if (arg_n == 2)
        *env = add_env(*env, arg[1], "");
    if (arg_n == 3) {
        *env = remove_env(*env, arg[1]);
        *env = add_env(*env, arg[1], arg[2]);
    }
}

void my_unsetenv(char ***env, char **arg)
{
    int arg_n = my_tablen(arg);

    if (arg_n == 1) {
        my_printf("unsetenv: Too few arguments.\n");
        return;
    }
    if (arg_n > 2) {
        my_printf("unsetenv: Too many arguments.\n");
        return;
    }
    *env = remove_env(*env, arg[1]);
}
