/*
** EPITECH PROJECT, 2021
** minishell
** File description:
** first
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include "../include/mysh.h"

void separate_line(char **env, char *first_part, char *second_part)
{
    for (int i = 0; second_part[i] != '\0'; i++)
        second_part[i] = second_part[i + 1];
    check_builtin(&env, first_part);
    if (my_strlen(second_part) > 2)
        check_builtin(&env, second_part);
}

void double_right(char *second_part)
{
    char *line_got = NULL;
    char *name = NULL;
    size_t size = 0;
    int i = 2;
    int start = 0;

    name = malloc(my_strlen(second_part) + 2);
    for (; second_part[i] == ' '; i++);
    for (start = i; second_part[i] != ' ' &&
    second_part[i] != '\n' && second_part[i] != '\0'; i++) {
        name[i - start] = second_part[i];
    }
    name[i - start] = '\n';
    name[i - start + 1] = '\0';
    while ((line_got == NULL || my_strcmp(name, line_got) != 0) &&
    getline(&line_got, &size, stdin) != -1) {
        if (line_got != NULL && my_strlen(line_got) > 1) {
            my_printf(line_got);
        }
    }
}
