/*
** EPITECH PROJECT, 2021
** minishell
** File description:
** first
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include "../include/mysh.h"

void find_redirect_next(char **env, char *first_part, char *second_part)
{
    if (second_part[0] == ';') {
        separate_line(env, first_part, second_part);
        return;
    }
    if (second_part[0] == '|') {
        piping(env, first_part, second_part);
        return;
    }
}

void find_redirect(char **env, char *first_part, char *second_part)
{
    if (second_part[0] == '<' && second_part[1] == '<') {
        double_right(second_part);
        return;
    }
    if (second_part[0] == '>' && second_part[1] == '>') {
        redirect_double(env, first_part, second_part);
        return;
    }
    if (second_part[0] == '<') {
        return;
    }
    if (second_part[0] == '>') {
        redirect_simple(env, first_part, second_part);
        return;
    }
    find_redirect_next(env, first_part, second_part);
}

void redirect_init(char **env, char *buffer)
{
    char *first_part = NULL;
    char *second_part = NULL;
    int i = 0;
    int start = 0;

    first_part = malloc(my_strlen(buffer));
    second_part = malloc(my_strlen(buffer));
    for (; buffer[i] != '|' && buffer[i] != '>' &&
    buffer[i] != '<' && buffer[i] != ';'; i++)
        first_part[i] = buffer[i];
    first_part[i] = '\0';
    for (start = i; buffer[i] != '\0'; i++)
        second_part[i - start] = buffer[i];
    second_part[i - start] = '\0';
    find_redirect(env, first_part, second_part);
}
