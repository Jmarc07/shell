/*
** EPITECH PROJECT, 2023
** B-PSU-200-TLS-2-1-42sh-jean-marc.naounou
** File description:
** env
*/

#include <stdlib.h>
#include "../include/mysh.h"

char **create_env(char **env)
{
    char **new_env = my_tabdup(env);

    return new_env;
}

char **add_env(char **env, char *key, char *value)
{
    int envlen = my_tablen(env);
    char **new_env = malloc(sizeof(char *) * (envlen + 2));
    char *val = malloc(sizeof(char) * (my_strlen(key) + my_strlen(value) + 3));

    if (new_env == NULL)
        return NULL;
    my_tabcpy(&new_env, env);
    val = my_strcpy(val, key);
    val = my_strcat(val, "=");
    val = my_strcat(val, value);
    new_env[envlen] = val;
    new_env[envlen + 1] = NULL;
    return new_env;
}

int get_env_index(char **env, char *key)
{
    int i = 0;
    int j = 0;

    for (; env[i] != NULL; i++) {
        for (j = 0; env[i][j] != '=' && env[i][j + 1] != '\0'; j++);
        if (my_strncmp(key, env[i], j) == 0)
            return i;
    }
    return -1;
}

char **remove_env(char **env, char *value)
{
    int i = 0;
    int j = 0;
    int k = 0;
    int envlen = my_tablen(env);
    char **new_env = malloc(sizeof(char *) * (envlen));

    if (new_env == NULL)
        return NULL;
    i = get_env_index(env, value);
    for (; env[j] != NULL; j++)
        if (j != i) {
            new_env[k] = env[j];
            k++;
        }
    new_env[k] = NULL;
    return new_env;
}
