/*
** EPITECH PROJECT, 2021
** minishell
** File description:
** first
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <fcntl.h>
#include "../include/mysh.h"

void use_pipe(char **env, char *second_part, int tube[2])
{
    pid_t pid = fork();

    if (pid == 0) {
        close(tube[1]);
        dup2(tube[0], STDIN_FILENO);
        close(tube[0]);
        for (int i = 0; second_part[i] != '\0'; i++) {
            second_part[i] = second_part[i + 1];
        }
        check_builtin(&env, second_part);
        exit(1);
    } else {
        wait(NULL);
    }
}

void piping(char **env, char *first_part, char *second_part)
{
    int tube[2];
    pid_t pid = fork();

    pipe(tube);
    if (pid == 0) {
        close(tube[0]);
        dup2(tube[1], STDOUT_FILENO);
        check_builtin(&env, first_part);
        exit(1);
    } else {
        use_pipe(env, second_part, tube);
    }
}

void redirect_double(char **env, char *first_part, char *second_part)
{
    char *name = NULL;
    int i = 2;
    int save = 0;
    int fd = 0;

    name = malloc(my_strlen(second_part));
    for (; second_part[i] == ' '; i++);
    for (int start = i; second_part[i] != ' ' &&
    second_part[i] != '\n' && second_part[i] != '\0'; i++) {
        name[i - start] = second_part[i];
    }
    fd = open(name, O_WRONLY | O_APPEND | O_CREAT
    | S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
    save = dup(STDOUT_FILENO);
    dup2(fd, STDOUT_FILENO);
    check_builtin(&env, first_part);
    dup2(save, STDOUT_FILENO);
}

void redirect_simple(char **env, char *first_part, char *second_part)
{
    int i = 1;
    char *name = NULL;
    int save = 0;
    int fd = 0;

    name = malloc(my_strlen(second_part));
    for (; second_part[i] == ' '; i++);
    for (int start = i; second_part[i] != ' ' &&
    second_part[i] != '\n' && second_part[i] != '\0'; i++) {
        name[i - start] = second_part[i];
    }
    fd = open(name, O_WRONLY | O_APPEND | O_CREAT
    | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
    save = dup(STDOUT_FILENO);
    dup2(fd, STDOUT_FILENO);
    check_builtin(&env, first_part);
    dup2(save, STDOUT_FILENO);
}
