/*
** EPITECH PROJECT, 2021
** minishell
** File description:
** first
*/

#include <stdlib.h>
#include <unistd.h>
#include "../include/mysh.h"

char *pwd(char *buff, char *start)
{
    int i = 0;
    char *final = malloc(my_strlen(buff) + my_strlen(start) + 1);

    for (; start[i] != '\0'; i++) {
        final[i] = start[i];
    }
    for (int j = 0; buff[j] != '\0';) {
        final[i] = buff[j];
        i++;
        j++;
    }
    final[i] = '\0';
    return (final);
}

char *without_pwd(char *buff, char *start)
{
    int i = 0;
    char *final = malloc(my_strlen(buff) + 1);

    for (; start[i] != '\0'; i++) {
        final[i] = start[i];
    }
    for (int j = 0; buff[j] != '\0';) {
        final[j] = buff[i];
        i++;
        j++;
    }
    final[i] = '\0';
    return (final);
}

char *home_pwd(char **env, char *start)
{
    int i = 0;

    for (; my_strcmp_uncomplete(start, env[i]) != 1; i++);
    return (without_pwd(env[i], start));
}

void display_error_cd_n(char *opt, char **env, char *save, char *buff)
{
    int i = 0;

    while (env[i + 1] != NULL)
        i++;
    if (access(opt, F_OK) == -1) {
        my_printf(opt);
        my_printf(": No such file or directory.\n");
        env[i] = save;
        return;
    }
    if (access(opt, R_OK) == -1) {
        my_printf(opt);
        my_printf(": Permission denied.\n");
        env[i] = save;
        return;
    }
    chdir(opt);
    getcwd(buff, sizeof(buff));
    env[21] = pwd(buff, "PWD=");
}

void display_error_cd(char **env, char **divised_line)
{
    char buff[100];
    int i = 0;
    char *save = NULL;

    if (divised_line[1] != NULL && divised_line[2] != NULL) {
        my_printf("cd: Too many arguments.\n");
        return;
    }
    while (env[i + 1] != NULL)
        i++;
    save = env[i];
    getcwd(buff, sizeof(buff));
    env[i] = pwd(buff, "OLDPWD=");
    if (divised_line[1] == NULL)
        divised_line[1] = home_pwd(env, "HOME=");
    if (divised_line[1][0] == '-')
        divised_line[1] = without_pwd(save, "OLDPWD=");
    display_error_cd_n(divised_line[1], env, save, buff);
}
