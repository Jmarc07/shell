/*
** EPITECH PROJECT, 2024
** minishell1
** File description:
** minishell
*/

#ifndef MINISHELL
    #define MINISHELL
    #include <stdio.h>
    #include <string.h>
    #include <stdlib.h>
    #include <unistd.h>
    #include <sys/types.h>
    #include <sys/wait.h>
    #include <signal.h>
    #include "my.h"
char **create_env(char **env);
char **add_env(char **env, char *key, char *value);
int get_env_index(char **env, char *key);
char **remove_env(char **env, char *key);
void my_unsetenv(char ***env, char **arg);
int my_setenv_checks(char **env, char **arg, int arg_n);
void my_setenv(char ***env, char **arg);
void print_env(char **env);
void my_exit(char **arg);
char *pwd(char *buff, char *start);
char *without_pwd(char *buff, char *start);
char *home_pwd(char **env, char *start);
void display_error_cd_n(char *opt, char **env, char *save, char *buff);
void display_error_cd(char **env, char **divised_line);
void specifique_function(char ***env, char **divised_line);
void error_execve(char *opt);
int execute(char **env, char **divised_line, char *buffer);
int check_builtin(char ***env, char *buffer);
char *copy_path(char *buffer, char *path);
char **copy_all(char *buffer);
int count_args(char *buffer, char tab);
void my_tabfree(char **tab);
char **my_tabdup(char **tab);
void my_tabcpy(char ***tab1, char **tab2);
int my_tablen(char **tab);
void parse_input(char *line, char ***commands);
void execute_command(char **args);
void handle_pipes(char ***commands, int num_commands);
void handle_redirections(char **args);

#endif /* !MINISHELL */
